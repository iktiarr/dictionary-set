ukm_pencinta_alam = set()
ukm_bulu_tangkis = set()
ukm_teater = set()
ukm_tari_tradisional = set()
mahasiswa1 = set()

print("-"*15 , "MENCARI DATA MAHASISWA YANG IKUT UKM ", "-"*15)
ukm_pencinta_alam_nama = int(input("Masukkan jumlah anggota UKM Pencinta Alam: "))
for i in range(ukm_pencinta_alam_nama):
    while True:
        mahasiswa = input("Masukkan nama: ")
        if mahasiswa.isalpha():
            ukm_pencinta_alam.add(mahasiswa)
            break
        else:
            print("Masukkan nama hanya boleh berisi huruf")

ukm_bulu_tangkis_nama = int(input("Masukkan jumlah anggota UKM Bulu Tangkis: "))
for i in range(ukm_bulu_tangkis_nama):
    while True:
        mahasiswa = input("Masukkan nama: ")
        if mahasiswa.isalpha():
            ukm_bulu_tangkis.add(mahasiswa)
            break
        else:
            print("Masukkan nama hanya boleh berisi huruf")

ukm_teater_nama = int(input("Masukkan jumlah anggota UKM Teater: "))
for i in range(ukm_teater_nama):
    while True:
        mahasiswa = input("Masukkan nama: ")
        if mahasiswa.isalpha():
            ukm_teater.add(mahasiswa)
            break
        else:
            print("Masukkan nama hanya boleh berisi huruf")

ukm_tari_tradisional_nama = int(input("Masukkan jumlah anggota UKM Tari Tradisional: "))
for i in range(ukm_tari_tradisional_nama):
    while True:
        mahasiswa = input("Masukkan nama: ")
        if mahasiswa.isalpha():
            ukm_tari_tradisional.add(mahasiswa)
            break
        else:
            print("Masukkan nama hanya boleh berisi huruf")

print("-"*50)
print("Daftar nama UKM beserta dengan nama anggotanya")
print("UKM Pencinta Alam:", ukm_pencinta_alam)
print("UKM Bulu Tangkis:", ukm_bulu_tangkis)
print("UKM Teater:", ukm_teater)
print("UKM Tari Tradisional:", ukm_tari_tradisional)
print("-"*50)

while True:
    print("-"*50)
    print("Pilih opsi yang ingin Anda jalankan:")
    print("1. Hitung dan tampilkan mahasiswa yang bergabung dalam lebih dari satu UKM")
    print("2. Tambahkan mahasiswa baru ke dalam UKM Pencinta Alam dan UKM Bulu Tangkis")
    print("3. Hapus mahasiswa dari UKM Bulu Tangkis")
    print("4. Tampilkan daftar UKM yang memiliki kurang dari 4 anggota")
    print("5. Tampilkan daftar mahasiswa yang tidak bergabung dalam UKM mana pun")
    print("0. Keluar")
    pilihan = input("Masukkan pilihan (0/1/2/3/4/5): ")

    if pilihan == "0":
        print("-"*50)
        print("===== TERIMA KASIH TELAH MENGGUNAKAN PROGRAM INI =====")
        print("-"*50)
        break
    elif pilihan == "1":
        ukm_gabung = [member for member in ukm_pencinta_alam | ukm_bulu_tangkis | ukm_teater | ukm_tari_tradisional if (member in ukm_pencinta_alam) + (member in ukm_bulu_tangkis) + (member in ukm_teater) + (member in ukm_tari_tradisional) > 1]
        print("Mahasiswa yang bergabung dalam lebih dari satu UKM:", ukm_gabung)
        print("-"*50)
    elif pilihan == "2":
        nama_mahasiswa_baru = input("Masukkan nama mahasiswa yang ingin ditambah : ")
        print("Pilih UKM yang ingin diikutinya : ")
        print("1. UKM Pencinta Alam")
        print("2. UKM Bulu Tangkis")
        print("3. UKM Teater")
        print("4. UKM Tari Tradisional")
        pilihan_ukm = input("Masukkan pilihan (1/2/3/4) : ")
        if pilihan_ukm == "1":
            ukm_pencinta_alam.add(nama_mahasiswa_baru)
            print(f"UKM Pencinta Alam: {ukm_pencinta_alam}")
            print("-"*50)
        elif pilihan_ukm == "2":
            ukm_bulu_tangkis.add(nama_mahasiswa_baru)
            print(f"UKM Bulu Tangkis: {ukm_bulu_tangkis}")
            print("-"*50)
        elif pilihan_ukm == "3":
            ukm_teater.add(nama_mahasiswa_baru)
            print(f"UKM Teater: {ukm_teater}")
            print("-"*50)
        elif pilihan_ukm == "4":
            ukm_tari_tradisional.add(nama_mahasiswa_baru)
            print(f"UKM Tari Tradisional: {ukm_tari_tradisional}")
            print("-"*50)
        else:
            print("Pilihan tidak valid. Coba pilih antara nomor 1, 2, 3 atau 4")
    elif pilihan == "3":
        nama_mahasiswa_hapus = input("Masukkan nama mahasiswa yang ingin dihapus : ")
        print("Pilih UKM yang ingin dihapusnya : ")
        print("1. UKM Pencinta Alam")
        print("2. UKM Bulu Tangkis")
        print("3. UKM Teater")
        print("4. UKM Tari Tradisional")
        pilihan_ukm = input("Masukkan pilihan (1/2/3/4) : ")
        if pilihan_ukm == "1":
            if nama_mahasiswa_hapus in ukm_pencinta_alam:
                ukm_pencinta_alam.remove(nama_mahasiswa_hapus)
                mahasiswa1.add(nama_mahasiswa_hapus)
            else:
                print(f"{nama_mahasiswa_hapus} tidak ditemukan di UKM Pecinta Alam")
            print(f"UKM Pecinta Alam : {ukm_pencinta_alam}")
            print("-"*50)
        elif pilihan_ukm == "2":
            if nama_mahasiswa_hapus in ukm_bulu_tangkis:
                ukm_bulu_tangkis.remove(nama_mahasiswa_hapus)
                mahasiswa1.add(nama_mahasiswa_hapus)
            else:
                print(f"{nama_mahasiswa_hapus} tidak ditemukan di UKM Bulu Tangkis")
            print(f"UKM Bulu Tangkis: {ukm_bulu_tangkis}")
            print("-"*50)
        elif pilihan_ukm == "3":
            if nama_mahasiswa_hapus in ukm_teater:
                ukm_teater.remove(nama_mahasiswa_hapus)
                mahasiswa1.add(nama_mahasiswa_hapus)
            else:
                print(f"{nama_mahasiswa_hapus} tidak ditemukan di UKM Teater")
            print(f"UKM Teater : {ukm_teater}")
            print("-"*50)
        elif pilihan_ukm == "4":
            if nama_mahasiswa_hapus in ukm_tari_tradisional:
                ukm_tari_tradisional.remove(nama_mahasiswa_hapus)
                mahasiswa1.add(nama_mahasiswa_hapus)
            else:
                print(f"{nama_mahasiswa_hapus} tidak ditemukan di UKM Tari Tradisional")
            print(f"UKM Tari Tradisional : {ukm_tari_tradisional}")
            print("-"*50)
        else:
            print("Pilihan tidak valid. Coba pilih antara nomor 1, 2, 3 atau 4")
    elif pilihan == "4":
        ukm_dengan_kurang_dari_4_anggota = []
        if len(ukm_pencinta_alam) < 4:
            ukm_dengan_kurang_dari_4_anggota.append("UKM Pencinta Alam")
        if len(ukm_bulu_tangkis) < 4:
            ukm_dengan_kurang_dari_4_anggota.append("UKM Bulu Tangkis")
        if len(ukm_teater) < 4:
            ukm_dengan_kurang_dari_4_anggota.append("UKM Teater")
        if len(ukm_tari_tradisional) < 4:
            ukm_dengan_kurang_dari_4_anggota.append("UKM Tari Tradisional")
        if ukm_dengan_kurang_dari_4_anggota:
            print("UKM yang kurang dari 4 anggota adalah ", ', '.join(ukm_dengan_kurang_dari_4_anggota))
            print("-"*50)
        else:
            print("Seluruh UKM memiliki anggota lebih dari 4")
    elif pilihan == "5":
        print("Mahasiswa yang tidak bergabung dalam UKM mana pun adalah ", mahasiswa1)
        print("-"*50)
    else:
        print("Pilihan tidak valid. Coba pilih antara nomor 0, 1, 2, 3, 4 atau 5")
