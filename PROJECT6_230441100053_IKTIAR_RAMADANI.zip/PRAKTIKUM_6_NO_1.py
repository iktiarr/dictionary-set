data_mahasisiwa = {
    "Nama": input("Masukkan nama anda: "),
    "Alamat": input("Masukkan alamat: "),
    "Prodi": input("Masukkan prodi anda: "),
    "Semester": int(input("Masukkan semester anda: ")),
    "Angkatan": int(input("Masukkan angkatan anda: "))
}
namaku = data_mahasisiwa["Nama"]

print("")
pindah = int(input("Pada tahun berapa " + namaku + " ingin pindah tempat tinggal ? "))
alamat = input("Dimanakah tempat tinggal baru " + namaku + " ? ")
prodi = input(namaku + " ingin beralih ke jenjang prodi baru apa ? ")
berhenti = int(input("Pada tahun berapa " + namaku + " memutuskan untuk berhenti menjadi mahasiswi? "))

data_mahasisiwa["Alamat"] = alamat
data_mahasisiwa["Prodi"] = prodi
data_mahasisiwa["Angkatan"] = pindah

print("")
print("Data Diri Setelah Perubahan:")
print("Nama:", data_mahasisiwa["Nama"])
print("Alamat:", data_mahasisiwa["Alamat"])
print("Prodi:", data_mahasisiwa["Prodi"])
print("Semester:", data_mahasisiwa["Semester"])
print("Angkatan:", data_mahasisiwa["Angkatan"])
print(namaku + " memutuskan untuk berhenti menjadi mahasiswi pada tahun", berhenti)